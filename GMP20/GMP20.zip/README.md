# Grave Music Player

Player para música ambiente da Grave

## APIs

* [fs module](http://nodejs.org/api/fs.html)
* [events module](http://nodejs.org/api/events.html)
* [path module](http://nodejs.org/api/path.html)
* [util module](http://nodejs.org/api/util.html)
* [child_process module](http://nodejs.org/api/child_process.html)
